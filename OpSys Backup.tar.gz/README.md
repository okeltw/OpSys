# OpSys
Lab work for Operating Systems class.  Language: C | Operating System: Linux (Ubuntu)

# Lab_2
kthreads and work_queues
- Create processes and clean them up. Properly kill zombie threads.

# Lab_3
Multiple threading. 
- Create two threads to process on a single array by incrementing each slot by one.

# Lab_4
Monitor battery status
- ACPI calls & decompiling. Monitor battery status and provide user with alerts at certain battery levels.
- Optional: utilize java widget to display battery info.


# Lab_5 [optional]
Pthreads, streams, locks
- Create a buffer such that one "Producer" can feed many "Consumers" with data.
- Use semaphores to pull the data and work with it.
[unfinished]

# Lab 6
Device Drivers, R/W Semaphores
- Simulate a device driver with a major/minor number
- Implement a R/W Sempahore to allow Read and Write interface from multiple sources
