sudo insmod netdriver.ko
sudo ifconfig os0 192.168.0.1
sudo ifconfig os1 192.168.1.1
